import React, { useState } from 'react';
import api from '../services/api.js';

export default function DatasetPage() {
  const [file, setFile] = useState(null);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) return;
    setLoading(true);
    setError(null);
    const formData = new FormData();
    formData.append('file', file);
    try {
      const res = await api.post('/upload_dataset', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setSummary(res.data);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to upload dataset');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold">Dataset Upload</h2>
        {error && <p className="text-red-500 mt-2 sm:mt-0">{error}</p>}
      </div>
      <form onSubmit={handleSubmit} className="card max-w-xl space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Upload CSV</label>
          <input
            type="file"
            accept=".csv"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="form-input w-full"
          />
        </div>
        <button
          type="submit"
          className="btn btn-primary"
          disabled={!file || loading}
        >
          {loading ? 'Uploading…' : 'Upload'}
        </button>
      </form>
      {summary && (
        <div className="card max-w-2xl">
          <h3 className="text-xl font-semibold mb-3">Dataset Summary</h3>
          <ul className="space-y-1 text-sm">
            <li><strong>Records:</strong> {summary.records}</li>
            <li><strong>Columns:</strong> {summary.columns.join(', ')}</li>
            <li><strong>Feature Columns:</strong> {summary.feature_columns.join(', ')}</li>
            <li><strong>Risk Distribution:</strong> {Object.entries(summary.target_distribution).map(([k,v]) => `${k}: ${v}`).join(', ')}</li>
            <li><strong>Model Metrics:</strong> {Object.entries(summary.model_metrics).map(([k,v]) => `${k}: ${v.toFixed(2)}`).join(', ')}</li>
          </ul>
        </div>
      )}
    </div>
  );
}