import React, { useEffect, useState } from 'react';
import api from '../services/api.js';

export default function ModelInsightsPage() {
  const [metrics, setMetrics] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchMetrics() {
      try {
        const res = await api.get('/model_insights');
        setMetrics(res.data);
      } catch (err) {
        setError('Failed to load model insights');
      }
    }
    fetchMetrics();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold">Model Insights</h2>
        {error && <p className="text-red-500 mt-2 sm:mt-0">{error}</p>}
      </div>
      {metrics ? (
        <div className="card max-w-xl">
          <h3 className="text-xl font-semibold mb-4">Performance Metrics</h3>
          <div className="grid gap-3 grid-cols-1 sm:grid-cols-2">
            <div className="p-3 rounded-lg border-l-4 border-success bg-success-light dark:bg-success-dark">
              <h4 className="text-sm font-medium text-gray-600 dark:text-gray-300">Accuracy</h4>
              <p className="text-2xl font-bold">{metrics.accuracy.toFixed(2)}</p>
            </div>
            <div className="p-3 rounded-lg border-l-4 border-info bg-info-light dark:bg-info-dark">
              <h4 className="text-sm font-medium text-gray-600 dark:text-gray-300">Precision</h4>
              <p className="text-2xl font-bold">{metrics.precision.toFixed(2)}</p>
            </div>
            <div className="p-3 rounded-lg border-l-4 border-warning bg-warning-light dark:bg-warning-dark">
              <h4 className="text-sm font-medium text-gray-600 dark:text-gray-300">Recall</h4>
              <p className="text-2xl font-bold">{metrics.recall.toFixed(2)}</p>
            </div>
            <div className="p-3 rounded-lg border-l-4 border-danger bg-danger-light dark:bg-danger-dark">
              <h4 className="text-sm font-medium text-gray-600 dark:text-gray-300">F1 Score</h4>
              <p className="text-2xl font-bold">{metrics.f1.toFixed(2)}</p>
            </div>
          </div>
          <p className="mt-6 text-sm text-gray-600 dark:text-gray-400">
            The current model uses a multi‑class logistic regression trained on your uploaded dataset. In future iterations, EduPulse Nexus may compare multiple models and provide confusion matrices and feature importances.
          </p>
        </div>
      ) : (
        <p>Loading…</p>
      )}
    </div>
  );
}