import React, { useEffect, useState } from 'react';
import api from '../services/api.js';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchStats() {
      try {
      const response = await api.get('/statistics');
        setStats(response.data);
      } catch (err) {
        setError('Failed to load statistics');
      }
    }
    fetchStats();
  }, []);

  const renderCards = () => {
    if (!stats) return null;
    const cards = [
      { title: 'Total Students', value: stats.records, color: 'info' },
      { title: 'Low Risk', value: stats.target_distribution?.Low ?? 0, color: 'success' },
      { title: 'Medium Risk', value: stats.target_distribution?.Medium ?? 0, color: 'warning' },
      { title: 'High Risk', value: stats.target_distribution?.High ?? 0, color: 'danger' },
    ];
    return (
      <div className="grid gap-4 mb-6 grid-cols-1 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => {
          // Map color keyword to tailwind utility classes. Tailwind does not evaluate dynamic strings.
          let bgClass = '';
          switch (card.color) {
            case 'success':
              bgClass = 'bg-success dark:bg-success-dark';
              break;
            case 'warning':
              bgClass = 'bg-warning dark:bg-warning-dark';
              break;
            case 'danger':
              bgClass = 'bg-danger dark:bg-danger-dark';
              break;
            case 'info':
            default:
              bgClass = 'bg-info dark:bg-info-dark';
              break;
          }
          return (
            <div
              key={card.title}
              className={`rounded-2xl p-6 shadow-md text-white ${bgClass}`}
            >
              <h3 className="text-lg font-semibold mb-1">{card.title}</h3>
              <p className="text-4xl font-extrabold">{card.value}</p>
            </div>
          );
        })}
      </div>
    );
  };

  const renderChart = () => {
    if (!stats) return null;
    // Convert numeric means into chart data
    const data = Object.keys(stats.numeric_means || {}).map((key) => ({
      name: key,
      mean: stats.numeric_means[key],
    }));
    return (
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data} margin={{ top: 16, right: 16, bottom: 0, left: 0 }}>
          <XAxis dataKey="name" tick={{ fill: 'currentColor', fontSize: 12 }} />
          <YAxis tick={{ fill: 'currentColor', fontSize: 12 }} />
          <Tooltip contentStyle={{ backgroundColor: 'rgba(255,255,255,0.9)', borderRadius: '0.5rem', padding: '0.5rem' }} />
          <Bar dataKey="mean" fill="#4f46e5" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    );
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold">Dashboard</h2>
        {error && <p className="text-red-500 mt-2 sm:mt-0">{error}</p>}
      </div>
      {renderCards()}
      {/* Narrative Insights */}
      {stats && (
        <div className="card">
          <h3 className="text-lg font-semibold mb-2">Narrative Insight</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {stats.records > 0
              ? `Based on the uploaded data, the majority of students are currently classified as ${stats.target_distribution.Low >= stats.target_distribution.Medium && stats.target_distribution.Low >= stats.target_distribution.High ? 'Low' : stats.target_distribution.Medium >= stats.target_distribution.High ? 'Medium' : 'High'} risk. The average attendance is ${stats.numeric_means?.attendancePercentage?.toFixed(1) ?? 'N/A'}% and students study approximately ${stats.numeric_means?.studyHoursPerWeek?.toFixed(1) ?? 'N/A'} hours per week.`
              : 'Upload a dataset to view insights.'}
          </p>
        </div>
      )}
      {/* Feature Means Chart */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-2">Feature Means</h3>
        {renderChart()}
      </div>
    </div>
  );
}