import React from 'react';
import { Link } from 'react-router-dom';

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="flex-1 flex flex-col justify-center items-center text-center px-6 py-16 bg-gradient-to-br from-primary via-secondary to-primary-dark dark:from-gray-800 dark:via-gray-900 dark:to-gray-800">
        <h1 className="text-5xl md:text-6xl font-extrabold text-white mb-6 leading-tight">
          Empower Your Academic Insights
        </h1>
        <p className="max-w-2xl text-lg md:text-xl text-white/90 mb-10">
          EduPulse Nexus is an AI‑powered early-warning and intervention platform to detect at‑risk students, analyze performance factors, explain risk drivers and plan effective interventions. Crafted as a polished minor project using FastAPI and React.
        </p>
        <div className="flex space-x-4">
          <Link
            to="/dashboard"
            className="btn btn-primary shadow-md"
          >
            Enter Dashboard
          </Link>
          <a
            href="#features"
            className="btn btn-secondary shadow-md"
          >
            Learn More
          </a>
        </div>
      </section>
      {/* Features Section */}
      <section id="features" className="py-16 bg-gray-50 dark:bg-gray-900 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">Why EduPulse Nexus?</h2>
          <div className="grid gap-8 md:grid-cols-3">
            {/* Feature card 1 */}
            <div className="card">
              <h3 className="text-xl font-semibold mb-2">Early Risk Detection</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Identify at‑risk students before it’s too late with AI-driven risk predictions and clear explanations.
              </p>
            </div>
            {/* Feature card 2 */}
            <div className="card">
              <h3 className="text-xl font-semibold mb-2">Deep Performance Analytics</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Visualize attendance, study habits, grades and more. Drill down into cohorts and compare trends over time.
              </p>
            </div>
            {/* Feature card 3 */}
            <div className="card">
              <h3 className="text-xl font-semibold mb-2">Actionable Interventions</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get personalized recommendations and simulate what‑if scenarios to plan the best path forward.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}