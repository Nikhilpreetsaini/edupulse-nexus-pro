import React, { useState } from 'react';
import api from '../services/api.js';

const defaultValues = {
  attendancePercentage: '',
  studyHoursPerWeek: '',
  previousGrade: '',
  assignmentCompletionRate: '',
  quizAverage: '',
  labPerformance: '',
  internalAssessmentScore: '',
  participationScore: '',
  sleepHours: '',
  stressLevel: '',
  extracurricularLoad: '',
  internetAccessQuality: '',
};

export default function PredictionPage() {
  const [values, setValues] = useState(defaultValues);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      // Convert empty strings to null for optional fields
      const payload = {};
      Object.keys(values).forEach((key) => {
        const val = values[key];
        payload[key] = val === '' ? null : parseFloat(val);
      });
      const res = await api.post('/predict', payload);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.detail || 'Prediction failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold">Predict Risk</h2>
        {error && <p className="text-red-500 mt-2 sm:mt-0">{error}</p>}
      </div>
      <form onSubmit={handleSubmit} className="card space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {Object.keys(defaultValues).map((key) => (
            <div key={key} className="flex flex-col">
              <label className="text-xs font-medium mb-1 capitalize" htmlFor={key}>{key.replace(/([A-Z])/g, ' $1')}</label>
              <input
                id={key}
                name={key}
                type="number"
                step="any"
                value={values[key]}
                onChange={handleChange}
                className="form-input"
              />
            </div>
          ))}
        </div>
        <button
          type="submit"
          className="btn btn-primary"
          disabled={loading}
        >
          {loading ? 'Predicting…' : 'Predict'}
        </button>
      </form>
      {result && (
        <div className="card border-l-4 mt-4" style={{ borderColor: result.riskLevel === 'Low' ? '#22c55e' : result.riskLevel === 'Medium' ? '#f59e0b' : '#ef4444' }}>
          <h3 className="text-xl font-semibold mb-2">Prediction Result</h3>
          <p className="text-lg">Risk Level: <span className="font-bold">{result.riskLevel}</span></p>
          <p className="text-sm mt-1">High Risk Probability: {(result.probability_high * 100).toFixed(2)}%</p>
        </div>
      )}
    </div>
  );
}