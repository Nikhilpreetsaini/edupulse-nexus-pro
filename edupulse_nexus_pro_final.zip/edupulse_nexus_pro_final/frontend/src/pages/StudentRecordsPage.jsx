import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api.js';

export default function StudentRecordsPage() {
  const [students, setStudents] = useState([]);
  const [error, setError] = useState(null);
  const [watchlist, setWatchlist] = useState(() => new Set());

  useEffect(() => {
    async function fetchStudents() {
      try {
        const response = await api.get('/students');
        setStudents(response.data);
      } catch (err) {
        setError('Failed to load students');
      }
    }
    fetchStudents();
  }, []);

  const toggleWatch = (index) => {
    const newSet = new Set(watchlist);
    if (newSet.has(index)) newSet.delete(index);
    else newSet.add(index);
    setWatchlist(newSet);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-3xl font-bold">Students</h2>
        {error && <p className="text-red-500 mt-2 sm:mt-0">{error}</p>}
      </div>
      <div className="card overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium tracking-wider">#</th>
              <th className="px-4 py-3 text-left text-xs font-medium tracking-wider">Attendance %</th>
              <th className="px-4 py-3 text-left text-xs font-medium tracking-wider">Study Hours</th>
              <th className="px-4 py-3 text-left text-xs font-medium tracking-wider">Prev Grade</th>
              <th className="px-4 py-3 text-left text-xs font-medium tracking-wider">Quiz Avg</th>
              <th className="px-4 py-3 text-left text-xs font-medium tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {students.map((stu, idx) => (
              <tr
                key={idx}
                className={
                  watchlist.has(idx)
                    ? 'bg-warning-light dark:bg-yellow-900'
                    : 'bg-white dark:bg-gray-900'
                }
              >
                <td className="px-4 py-3 text-sm">{idx + 1}</td>
                <td className="px-4 py-3 text-sm">{stu.attendancePercentage?.toFixed?.(2) ?? '-'}</td>
                <td className="px-4 py-3 text-sm">{stu.studyHoursPerWeek?.toFixed?.(2) ?? '-'}</td>
                <td className="px-4 py-3 text-sm">{stu.previousGrade?.toFixed?.(2) ?? '-'}</td>
                <td className="px-4 py-3 text-sm">{stu.quizAverage?.toFixed?.(2) ?? '-'}</td>
                <td className="px-4 py-3 text-sm flex space-x-2 items-center">
                  <Link
                    to={`/student/${idx}`}
                    className="text-primary hover:underline"
                  >
                    View
                  </Link>
                  <button
                    onClick={() => toggleWatch(idx)}
                    className="text-xs px-2 py-1 rounded-full border border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    {watchlist.has(idx) ? 'Unwatch' : 'Watch'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}