import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './pages/LandingPage.jsx';
import DashboardPage from './pages/DashboardPage.jsx';
import StudentRecordsPage from './pages/StudentRecordsPage.jsx';
import StudentProfilePage from './pages/StudentProfilePage.jsx';
import DatasetPage from './pages/DatasetPage.jsx';
import PredictionPage from './pages/PredictionPage.jsx';
import SimulatorPage from './pages/SimulatorPage.jsx';
import ModelInsightsPage from './pages/ModelInsightsPage.jsx';
import Navbar from './components/Navbar.jsx';
import Sidebar from './components/Sidebar.jsx';

// Layout with a top navigation bar and left sidebar for medium+ screens.
function Layout({ children }) {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 flex flex-col">
      {/* Top navigation bar */}
      <Navbar />
      <div className="flex-1 flex">
        {/* Sidebar for large screens */}
        <Sidebar />
        {/* Main content */}
        <main className="flex-1 p-4 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/dashboard" element={<Layout><DashboardPage /></Layout>} />
      <Route path="/students" element={<Layout><StudentRecordsPage /></Layout>} />
      <Route path="/student/:id" element={<Layout><StudentProfilePage /></Layout>} />
      <Route path="/dataset" element={<Layout><DatasetPage /></Layout>} />
      <Route path="/predict" element={<Layout><PredictionPage /></Layout>} />
      <Route path="/simulate" element={<Layout><SimulatorPage /></Layout>} />
      <Route path="/insights" element={<Layout><ModelInsightsPage /></Layout>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}