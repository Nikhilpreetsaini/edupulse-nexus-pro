import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Top navigation bar used across the application.
 * Contains the site title on the left and a horizontal nav for medium+ screens.
 * For small screens, navigation is primarily available via the sidebar.
 */
export default function Navbar() {
  return (
    <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
        {/* Branding */}
        <div className="flex items-center space-x-3">
          {/* Replace with your own logo if available */}
          <span className="text-2xl font-extrabold text-primary">EduPulse</span>
          <span className="hidden sm:inline text-lg font-light text-primary-dark">Nexus</span>
        </div>
        {/* Primary navigation for medium+ screens */}
        <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
          <Link to="/dashboard" className="hover:text-primary-dark">Dashboard</Link>
          <Link to="/students" className="hover:text-primary-dark">Students</Link>
          <Link to="/dataset" className="hover:text-primary-dark">Dataset</Link>
          <Link to="/predict" className="hover:text-primary-dark">Predict</Link>
          <Link to="/simulate" className="hover:text-primary-dark">Simulate</Link>
          <Link to="/insights" className="hover:text-primary-dark">Model Insights</Link>
        </nav>
      </div>
    </header>
  );
}