import React from 'react';
import { Link, useLocation } from 'react-router-dom';

/**
 * Left sidebar navigation for larger screens. Highlights the active route.
 */
export default function Sidebar() {
  const location = useLocation();
  const items = [
    { label: 'Dashboard', path: '/dashboard' },
    { label: 'Students', path: '/students' },
    { label: 'Dataset', path: '/dataset' },
    { label: 'Predict', path: '/predict' },
    { label: 'Simulate', path: '/simulate' },
    { label: 'Model Insights', path: '/insights' },
  ];
  return (
    <aside className="hidden lg:block lg:w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 overflow-y-auto">
      <div className="p-4">
        <h2 className="text-xl font-bold mb-6">Navigation</h2>
        <nav className="space-y-1">
          {items.map((item) => {
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={
                  'block px-4 py-2 rounded-lg text-sm font-medium transition-colors ' +
                  (active
                    ? 'bg-primary text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800')
                }
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
}