import axios from 'axios';

// Create an axios instance with a base URL pointing at the backend
// During development the backend runs on port 8000 when launched via uvicorn.
// Adjust the URL if you deploy the backend behind a different host or port.
// Use the deployed backend URL in production. When running locally you can
// override this with an environment variable or adjust as needed.
const api = axios.create({
  baseURL: 'https://edupulse-nexus-pro-backend.onrender.com',
});

export default api;